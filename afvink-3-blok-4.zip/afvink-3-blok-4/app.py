from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)


@app.route('/')
def search():
    """
    Geeft de search pagina aan
    :return: een render template van de search pagina
    """
    return render_template("base.html")


@app.route('/afvink3', methods=["POST"])
def result():
    """
    maakt een connectie met de database en geeft het zoek term door in een POST
    :return: een render template van de result pagina
    """
    # maakt een connectie met de database
    conn = mysql.connector.connect(
        host="ensembldb.ensembl.org",
        user="anonymous",
        db="homo_sapiens_core_95_38",
        passwd="")
    # een post method
    if request.method == "POST":
        term = request.form["term"]
        cursor = conn.cursor()
        # geeft een sql query waarbij de term een input is
        exec_string = "SELECT * FROM gene WHERE description LIKE '%" + term + "%'"
        if term != '':
            cursor.execute(exec_string)
            rows = cursor.fetchall()
        else:
            term = '%'
            cursor.execute(exec_string)
        # geeft een render template van de result pagina
        return render_template("afvink3.html", rows=rows, term=term)


if __name__ == '__main__':
    app.run()
